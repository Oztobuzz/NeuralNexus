import numpy as np
from random import shuffle

def softmax_loss_vectorized(W, X, y, reg):
  """
  Softmax loss function, vectorized version.
  Inputs:
  - W: C x D array of weights
  - X: D x N array of data. Data are D-dimensional columns
  - y: 1-dimensional array of length N with labels 0...K-1, for K classes
  - reg: (float) regularization strength
  Returns:
  a tuple of:
  - loss as single float
  - gradient with respect to weights W, an array of same size as W
  """
  # Initialize the loss and gradient to zero.
  loss = 0.0
  dW = np.zeros_like(W)
  num_samples = X.shape[1]

    
  #############################################################################
  # TODO: Compute the softmax loss and its gradient using no explicit loops.  #
  # Store the loss in loss and the gradient in dW. If you are not careful     #
  # here, it is easy to run into numeric instability. Don't forget the        #
  # regularization!                                                           #
  # #############################################################################
  z = W@X # CxD * DxN = CxN
  
  # Calculate softmax, softmax(x) = softmax(x+c)
  z += -np.max(z, axis=0)
  sum_of_softmax = np.sum(np.exp(z), axis = 0) #Scale to prevent underflow 
    
  # print(y.shape)  # 49000
  # print(z.shape)  # 10x49000
  
  ## Get the values at position j in y 
  y_score = z[y, range(num_samples)]


  # Calculate loss 
  # log(exp(y_score)) = y_score 
  # log(exp(y_score)/(sum_of_softmax)) = y_score - log(sum_of_softmax)
  loss =  (-1/num_samples) * (np.sum(y_score - np.log(sum_of_softmax))) + 0.5*reg*np.sum(W*W)
  
  # Calculate dW
  z = np.exp(z)/sum_of_softmax 
  z[y, range(num_samples)] -= 1 
  
  dLW = (1/num_samples)*(z@np.transpose(X)) #CxN * NxD = CxD
  dRW = reg*(W) 
  dW = dLW + dRW
  
  # print(dRW.shape) # CxD
  # print(dLW.shape) # CxD
  
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

  pass
  #############################################################################
  #                          END OF YOUR CODE                                 #
  #############################################################################

  return loss, dW
