import numpy as np
from random import shuffle

def softmax_loss_vectorized(W, X, y, reg):
  """
  Softmax loss function, vectorized version.
  Inputs:
  - W: C x D array of weights
  - X: D x N array of data. Data are D-dimensional columns
  - y: 1-dimensional array of length N with labels 0...K-1, for K classes
  - reg: (float) regularization strength
  Returns:
  a tuple of:
  - loss as single float
  - gradient with respect to weights W, an array of same size as W
  """
  # Initialize the loss and gradient to zero.
  loss = 0.0
  dW = np.zeros_like(W)
  num_samples = X.shape[1]
  # print(num_samples)
  #############################################################################
  # TODO: Compute the softmax loss and its gradient using no explicit loops.  #
  # Store the loss in loss and the gradient in dW. If you are not careful     #
  # here, it is easy to run into numeric instability. Don't forget the        #
  # regularization!                                                           #
  #############################################################################
  # z = W*X  (CxD * DxN = CxN) class x samples
  z = W@X # CxD * DxN = CxN
  # Calculate softmax 
  z = np.exp(z)/np.sum(np.exp(z), axis = 0) 

  # print(y.shape)
  # print(y_pred.shape)  
    
  ## Get the values at position j in y 
  y_pred = np.reshape(z,(num_samples, -1))
  y_pred = y_pred[np.arange(len(y_pred)), y]
  # print(y_pred.shape)

  # Calculate loss 
  # loss_vector = np.sum(np.log(y_pred))
  loss =   (-1/num_samples) * (np.sum(np.log(y_pred)))
  z = np.reshape(z, (num_samples, -1))
  # print(z.shape) 
  # print(y)
  # print(z[0][6], z[0][7])
  z[np.arange(len(z)), y] -= 1
  # print(z[0][6], z[0][7])
  dLW = (1/num_samples)*(np.transpose(z)@np.transpose(X)) #CxN * NxD = CxD
  dRW = reg*(np.sum(W, axis = 1)) 
  # print(dRW.shape) # Cx1
  # print(dLW.shape) # CxD
  dW = np.transpose(np.transpose(dLW) + np.transpose(dRW)) # (3073,10) + (1,10)
    
  # dW = np.transpose(np.transpose(dLW)) # (3073,10) + (1,10)
  # dW_i =  (P_i -1)*x  = (z_i - 1)*x =   CxN * DxN
  # dW_j =  P_j*x  = (z_j)*x = 
  
  pass
  #############################################################################
  #                          END OF YOUR CODE                                 #
  #############################################################################

  return loss, dW
