import numpy as np

def affine_forward(x, w, b):
  """
  Computes the forward pass for an affine (fully-connected) layer.

  The input x has shape (N, d_1, ..., d_k) where x[i] is the ith input.
  We multiply this against a weight matrix of shape (D, M) where
  D = \prod_i d_i

  Inputs:
  x - Input data, of shape (N, d_1, ..., d_k)
  w - Weights, of shape (D, M)
  b - Biases, of shape (M,)
  
  Returns a tuple of:
  - out: output, of shape (N, M)
  - cache: (x, w, b)
  """
  out = None
  N = x.shape[0]
  #############################################################################
  # TODO: Implement the affine forward pass. Store the result in out. You     #
  # will need to reshape the input into rows.                                 #
  ##############################################################fadsfadsfadsf###############
  
  out = x.reshape(N, -1)@w + b  # N, D * D, M  + M, =  N, M
  
  ############################################################################fdfsdfds#
  #                             END OF YOUR CODE                              #
  #############################################################################
  cache = (x, w, b)
  return out, cache


def affine_backward(dout, cache):
  """
  Computes the backward pass for an affine layer.

  Inputs:
  - dout: Upstream derivative, of shape (N, M)
  - cache: Tuple of:
    - x: Input data, of shape (N, d_1, ... d_k)
    - w: Weights, of shape (D, M)

  Returns a tuple of:
  - dx: Gradient with respect to x, of shape (N, d1, ..., d_k)
  - dw: Gradient with respect to w, of shape (D, M)
  - db: Gradient with respect to b, of shape (M,)
  """
  x, w, b = cache
  dx, dw, db = None, None, None
  N = x.shape[0]
  #############################################################################
  # TODO: Implement the affine backward pass.                                 #
  #############################################################################
  
  dx = dout@np.transpose(w)
  dx = dx.reshape(x.shape) 
  dw = np.transpose(x.reshape(N, -1))@dout
  db = np.sum(dout, axis = 0)
  # pass
  #############################################################################
  #                             END OF YOUR CODE                              #
  #############################################################################
  return dx, dw, db


def relu_forward(x):
  """
  Computes the forward pass for a layer of rectified linear units (ReLUs).

  Input:
  - x: Inputs, of any shape

  Returns a tuple of:
  - out: Output, of the same shape as x
  - cache: x
  """
  out = None
  #############################################################################
  # TODO: Implement the ReLU forward pass.                                    #
  #############################################################################
  # out = x()
  out = np.where(x < 0, 0, x) 
  #############################################################################
  #                             END OF YOUR CODE                              #
  #############################################################################
  cache = x
  return out, cache


def relu_backward(dout, cache):
  """
  Computes the backward pass for a layer of rectified linear units (ReLUs).

  Input:
  - dout: Upstream derivatives, of any shape
  - cache: Input x, of same shape as dout

  Returns:
  - dx: Gradient with respect to x
  """
  dx, x = None, cache
  #############################################################################
  # TODO: Implement the ReLU backward pass.                                   #
  #############################################################################
  dx = np.where(x < 0, 0, 1)
  # print(np.where(x < 0, 0, 1))
  # print(x > 0)
  dx = dout*dx
  # pass
  #############################################################################
  #                             END OF YOUR CODE                              #
  #############################################################################
  return dx


def conv_forward_naive(x, w, b, conv_param):
  """
  A naive implementation of the forward pass for a convolutional layer.

  The input consists of N data points, each with C channels, height H and width
  W. We convolve each input with F different filters, where each filter spans
  all C channels and has height HH and width HH.

  Input:
  - x: Input data of shape (N, C, H, W)
  - w: Filter weights of shape (F, C, HH, WW)
  - b: Biases, of shape (F,)
  - conv_param: A dictionary with the following keys:
    - 'stride': The number of pixels between adjacent receptive fields in the
      horizontal and vertical directions.
    - 'pad': The number of pixels that will be used to zero-pad the input.

  Returns a tuple of:
  - out: Output data, of shape (N, F, H', W') where H' and W' are given by
    H' = 1 + (H + 2 * pad - HH) / stride
    W' = 1 + (W + 2 * pad - WW) / stride
  - cache: (x, w, b, conv_param)
  """
  out = None
  N, _ , H, W = x.shape
  stride, pad = conv_param.values()
  # print(pad)
  F, C, HH, WW = w.shape
  #############################################################################
  # TODO: Implement the convolutional forward pass.                           #
  # Hint: you can use the function np.pad for padding.                        #
  #############################################################################
  H_out =  int(1 + (H + 2 * pad - HH) / stride)
  W_out =  int(1 + (W + 2 * pad - WW) / stride)
  x = np.pad(x, ((0,0),(0,0),(pad,pad),(pad,pad)), 'constant')
  # print(H_out, W_out)
  samples_result = []
  for n in range(0,N):
    filters_result = []
    for f in range(0,F): 
      channels_result = []
      for c in range(0,C):
        channel_result = []
        for h_out in range(0, H_out):
          for w_out in range(0, W_out):
            el = x[n, c, h_out*stride:h_out*stride+HH, w_out*stride:w_out*stride+WW] * w[f,c,:,:]
            channel_result.append(np.sum(el))
        channel_result = np.stack(channel_result)
        channel_result = channel_result.reshape(H_out, W_out)
        channels_result.append(channel_result)
      el = np.stack(channels_result)
      filter_result = np.sum(el, axis = 0) + b[f]
      filters_result.append(filter_result)
    sample = np.stack(filters_result) 
    # print(sample.shape)
    samples_result.append(sample)
  out = np.stack(samples_result)
    
  # pass
  #############################################################################
  #                             END OF YOUR CODE                              #
  #############################################################################
  # out = np.array(out)
  # out = out.reshape(N, F, H_out, W_out)
  # print(out.shape)
  cache = (x, w, b, conv_param)
  return out, cache


def conv_backward_naive(dout, cache):
  """
  A naive implementation of the backward pass for a convolutional layer.

  Inputs:
  - dout: Upstream derivatives.
  - cache: A tuple of (x, w, b, conv_param) as in conv_forward_naive

  Returns a tuple of:
  - dx: Gradient with respect to x
  - dw: Gradient with respect to w
  - db: Gradient with respect to b
  """
  dx, dw, db = None, None, None
  x, w, b, conv_param = cache
  stride, pad = conv_param.values()
  #############################################################################
  # TODO: Implement the convolutional backward pass.                          #
  #############################################################################
  dx = np.zeros(x.shape)
  dw = np.zeros(w.shape)
  db = np.zeros(b.shape)
  
  F, _, HH, WW = w.shape
  N, C_out, H, W = dout.shape
  C_in = x.shape[1]
  print(N, C_out, H, W, C_in)

  ##Dx
  #Calculate dx
  for n in range(0,N):
    for c_in in range(0,C_in):
      for h in range(0,H):
        for wi in range(0,W):
          for f in range(0, F):
            dx[n, c_in, h*stride: h*stride + HH, wi*stride: wi*stride+WW] += dout[n, f, h, wi]*w[f, c_in, :, :]
  # Unpadding dx
  dx = dx[:,:, pad:-pad, pad:-pad]
  
  ##Dw
  for f in range(0, F):
    for c_in in range(0, C_in):
      for h in range(0, H):
        for wi in range(0, W):
          for n in range(0, N):
            dw[f, c_in, :, :] += dout[n, f, h, wi]*x[n, c_in, h*stride:h*stride+HH, wi*stride:wi*stride+WW]

  ##Db 
  db = db + np.sum(dout, axis = (0,2,3))
  pass
  #############################################################################
  #                             END OF YOUR CODE                              #
  #############################################################################
  return dx, dw, db


def max_pool_forward_naive(x, pool_param):
  """
  A naive implementation of the forward pass for a max pooling layer.

  Inputs:
  - x: Input data, of shape (N, C, H, W)
  - pool_param: dictionary with the following keys:
    - 'pool_height': The height of each pooling region
    - 'pool_width': The width of each pooling region
    - 'stride': The distance between adjacent pooling regions

  Returns a tuple of:
  - out: Output data
  - cache: (x, pool_param)
  """
  out = None
  #############################################################################
  # TODO: Implement the max pooling forward pass                              #
  #############################################################################
  N, C, H, W = x.shape
  pool_height, pool_width, stride = pool_param.values()
  
  H_out =  int(1 + (H - pool_height) / stride)
  W_out =  int(1 + (W - pool_width) / stride)
  out = np.zeros((N,C,H_out, W_out))
  
  for n in range(0, N):
    for c in range(0,C):
      for h_out in range(0, H_out):
        for w_out in range(0, W_out):
          out[n,c,h_out,w_out] = np.max(x[n,c,h_out*stride:h_out*stride+pool_height, w_out*stride:w_out*stride+pool_width])
  
  
  pass
  #############################################################################
  #                             END OF YOUR CODE                              #
  #############################################################################
  cache = (x, pool_param)
  return out, cache


def max_pool_backward_naive(dout, cache):
  """
  A naive implementation of the backward pass for a max pooling layer.

  Inputs:
  - dout: Upstream derivatives
  - cache: A tuple of (x, pool_param) as in the forward pass.

  Returns:
  - dx: Gradient with respect to x
  """
  dx = None
  x, pool_param = cache
  #############################################################################
  # TODO: Implement the max pooling backward pass                             #
  #############################################################################  
  N, C, H, W = x.shape
  pool_height, pool_width, stride = pool_param.values()
  _,_,H_out, W_out = dout.shape
  dx = np.zeros(x.shape)
  
  for n in range(0, N):
    for c in range(0,C):
      for h_out in range(0, H_out):
        for w_out in range(0, W_out):
          #Getting the max idx of the pool
          idx = np.unravel_index(np.argmax(x[n,c,h_out*stride:h_out*stride+pool_height, w_out*stride:w_out*stride+pool_width], axis = None),(N,C,pool_height,pool_width))
          # Update the max idx with the dout
          dx[n,c,h_out*stride:h_out*stride+pool_height, w_out*stride:w_out*stride+pool_width][idx[2], idx[3]] += 1*dout[n,c,h_out,w_out]
  
  pass
  #############################################################################
  #                             END OF YOUR CODE                              #
  #############################################################################
  return dx


def svm_loss(x, y):
  """
  Computes the loss and gradient using for multiclass SVM classification.

  Inputs:
  - x: Input data, of shape (N, C) where x[i, j] is the score for the jth class
    for the ith input.
  - y: Vector of labels, of shape (N,) where y[i] is the label for x[i] and
    0 <= y[i] < C

  Returns a tuple of:
  - loss: Scalar giving the loss
  - dx: Gradient of the loss with respect to x
  """
  N = x.shape[0]
  correct_class_scores = x[np.arange(N), y]
  margins = np.maximum(0, x - correct_class_scores[:, np.newaxis] + 1.0)
  margins[np.arange(N), y] = 0
  loss = np.sum(margins) / N
  num_pos = np.sum(margins > 0, axis=1)
  dx = np.zeros_like(x)
  dx[margins > 0] = 1
  dx[np.arange(N), y] -= num_pos
  dx /= N
  return loss, dx


def softmax_loss(x, y):
  """
  Computes the loss and gradient for softmax classification.

  Inputs:
  - x: Input data, of shape (N, C) where x[i, j] is the score for the jth class
    for the ith input.
  - y: Vector of labels, of shape (N,) where y[i] is the label for x[i] and
    0 <= y[i] < C

  Returns a tuple of:
  - loss: Scalar giving the loss
  - dx: Gradient of the loss with respect to x
  """
  probs = np.exp(x - np.max(x, axis=1, keepdims=True))
  probs /= np.sum(probs, axis=1, keepdims=True)
  N = x.shape[0]
  loss = -np.sum(np.log(probs[np.arange(N), y])) / N
  dx = probs.copy()
  dx[np.arange(N), y] -= 1
  dx /= N
  return loss, dx

